import OpenAI from "openai";
import { OPENAI_API_KEY } from "../config/env.js";

let client = null;

if (!OPENAI_API_KEY) {
  console.warn("[WARN] OPENAI_API_KEY not set. LLM responses will fail.");
} else {
  client = new OpenAI({ apiKey: OPENAI_API_KEY });
}

export async function llmChat(messages) {
  if (!client) throw new Error("LLM client not configured");

  const response = await client.chat.completions.create({
    model: "gpt-4.1-mini",
    messages,
    temperature: 0.4,
    max_tokens: 400
  });

  return (response.choices?.[0]?.message?.content || "").trim();
}
