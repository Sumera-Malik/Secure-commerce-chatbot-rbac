import sqlite3 from "sqlite3";
import { open } from "sqlite";
import bcrypt from "bcrypt";

let dbPromise = null;

export function getDB() {
  if (!dbPromise) {
    dbPromise = open({
      filename: "./securechat.db",
      driver: sqlite3.Database
    }).then(async (db) => {
      await db.exec(`
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL,
          passwordHash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'customer',
          mfaEnabled INTEGER NOT NULL DEFAULT 1,
          mfaSecret TEXT
        );

        CREATE TABLE IF NOT EXISTS chat_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId INTEGER,
          role TEXT,
          request TEXT,
          response TEXT,
          timestamp TEXT,
          prevHash TEXT,
          hash TEXT,
          flagged INTEGER DEFAULT 0,
          flagReason TEXT,
          FOREIGN KEY (userId) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS demo_orders (
          id INTEGER PRIMARY KEY,
          userId INTEGER,
          total INTEGER,
          status TEXT,
          FOREIGN KEY (userId) REFERENCES users(id)
        );
      `);

      // Seed admin + demo customer + demo order if not present
      const admin = await db.get(
        "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
      );

      if (!admin) {
        const adminHash = await bcrypt.hash("Admin@123", 10);
        const { lastID: adminId } = await db.run(
          "INSERT INTO users (name, email, passwordHash, role, mfaEnabled) VALUES (?, ?, ?, ?, ?)",
          ["Admin", "admin@example.com", adminHash, "admin", 1]
        );
        console.log(
          "Seeded admin (admin@example.com / Admin@123)",
          adminId
        );

        const custHash = await bcrypt.hash("Customer@123", 10);
        const { lastID: custId } = await db.run(
          "INSERT OR IGNORE INTO users (name, email, passwordHash, role, mfaEnabled) VALUES (?, ?, ?, ?, ?)",
          ["Demo Customer", "customer@example.com", custHash, "customer", 1]
        );

        await db.run(
          "INSERT OR IGNORE INTO demo_orders (id, userId, total, status) VALUES (101, ?, 7999, 'Shipped')",
          custId
        );
      }

      return db;
    });
  }
  return dbPromise;
}
