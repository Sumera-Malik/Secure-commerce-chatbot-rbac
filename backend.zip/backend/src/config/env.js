// backend/src/config/env.js
import dotenv from "dotenv";

dotenv.config();

function required(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

// Port for Express
export const PORT = process.env.PORT || 4000;

// Strong secret required – no insecure default
export const JWT_SECRET = required("JWT_SECRET");

// Optional in dev, but should be set in real deployment
export const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
export const EMAIL_USER = process.env.EMAIL_USER || "";
export const EMAIL_PASS = process.env.EMAIL_PASS || "";

// Frontend origin for CORS
export const CORS_ORIGIN =
  process.env.CORS_ORIGIN || "http://localhost:3000";
