// backend/src/utils/redact.js

/**
 * Very simple redaction of obviously sensitive patterns
 * (card numbers, long digit sequences, password/cvv/otp style secrets).
 * This is used BEFORE writing logs to the database.
 */
export function redactSensitive(text = "") {
  if (!text || typeof text !== "string") return text;

  let result = text;

  // Common card number pattern: 4-4-4-4 digits with optional spaces/dashes
  result = result.replace(
    /\b(\d{4}[-\s]?){3}\d{4}\b/g,
    "[REDACTED_CARD]"
  );

  // Any really long digit sequence (13–19 digits) – likely card / account numbers
  result = result.replace(/\b\d{13,19}\b/g, "[REDACTED_DIGITS]");

  // Password / CVV / CVC / OTP style "key=value" or "key: value"
  result = result.replace(
    /\b(password|pass|cvv|cvc|otp)\s*[:=]\s*\S+/gi,
    (match) => {
      const key = match.split(/[:=]/)[0];
      return `${key}=[REDACTED]`;
    }
  );

  return result;
}
