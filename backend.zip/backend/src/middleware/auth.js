// backend/src/middleware/auth.js
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../config/env.js";

// Very simple in-memory blacklist for demo / assignment purposes
const revokedTokens = new Set();

/**
 * Mark a token as revoked (used on logout).
 */
export function revokeToken(token) {
  if (token) {
    revokedTokens.add(token);
  }
}

/**
 * Require a valid, non-revoked JWT in the Authorization header.
 * Attaches decoded user payload as req.user.
 */
export function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Missing token" });
  }

  const token = header.split(" ")[1];

  if (revokedTokens.has(token)) {
    return res.status(401).json({ message: "Token revoked" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    // decoded: { sub, role, name, email, iat, exp }
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}
