// backend/src/routes/chat.js
import express from "express";
import crypto from "crypto";
import { requireAuth } from "../middleware/auth.js";
import { sanitizeBody } from "../middleware/sanitize.js";
import { getDB } from "../config/db.js";
import { generateSecureLLMAnswer } from "../services/aiService.js";
import { redactSensitive } from "../utils/redact.js";

const router = express.Router();

// Simple in-memory pointer to last log hash for chaining
let lastHash = "";

// Very lightweight anomaly counter (for NFR7)
const abuseCounters = new Map(); // userId -> { count, windowStart }
const ABUSE_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const ABUSE_THRESHOLD = 5; // flagged chats in window

router.post("/", requireAuth, sanitizeBody, async (req, res) => {
  const { query } = req.body;
  const user = req.user;

  // 🔹 Only very basic check – no express-validator, no "Invalid input."
  if (!query || typeof query !== "string") {
    return res.status(400).json({ message: "Query is required" });
  }

  try {
    // Ask the LLM with secure prompting
    const { answer, flagged, flagReason } = await generateSecureLLMAnswer(
      query,
      user
    );

    const timestamp = new Date().toISOString();
    const prevHash = lastHash || "";

    // REDACT SENSITIVE DATA BEFORE LOGGING OR HASHING
    const safeRequest = redactSensitive(query);
    const safeAnswer = redactSensitive(answer);

    // Hash chain = SHA256(prevHash + userId + role + request + response + timestamp)
    const hash = crypto
      .createHash("sha256")
      .update(
        prevHash +
          String(user.sub) +
          String(user.role) +
          safeRequest +
          safeAnswer +
          timestamp
      )
      .digest("hex");

    const db = await getDB();
    await db.run(
      `INSERT INTO chat_logs
        (userId, role, request, response, timestamp, prevHash, hash, flagged, flagReason)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        user.sub,
        user.role,
        safeRequest,
        safeAnswer,
        timestamp,
        prevHash,
        hash,
        flagged ? 1 : 0,
        flagReason || null
      ]
    );

    lastHash = hash;

    // Very simple anomaly detection: many flagged chats in short window
    if (flagged) {
      const now = Date.now();
      const record =
        abuseCounters.get(user.sub) || { count: 0, windowStart: now };

      if (now - record.windowStart > ABUSE_WINDOW_MS) {
        // reset window
        record.count = 0;
        record.windowStart = now;
      }

      record.count += 1;
      abuseCounters.set(user.sub, record);

      if (record.count >= ABUSE_THRESHOLD) {
        console.warn(
          `[ALERT] Suspicious activity from user ${user.sub}: ` +
            `${record.count} flagged chats in the last 10 minutes`
        );
        // Optionally: here you could start blocking or further restricting
      }
    }

    // Return ORIGINAL answer text to the user
    return res.json({ answer, flagged, flagReason });
  } catch (err) {
    console.error("Chat error:", err);
    // Safe fallback, do not leak stack traces
    return res.status(200).json({
      answer:
        "I’m facing an internal issue talking to the AI right now, but your request is logged securely. Please try again later.",
      flagged: true,
      flagReason: "internal_error_fallback"
    });
  }
});

export default router;
