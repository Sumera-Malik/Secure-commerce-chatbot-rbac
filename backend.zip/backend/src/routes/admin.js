import express from "express";
import { requireAuth } from "../middleware/auth.js";
import { requireRole } from "../middleware/rbac.js";
import { getDB } from "../config/db.js";

const router = express.Router();

router.get(
  "/logs",
  requireAuth,
  requireRole(["admin"]),
  async (_req, res) => {
    try {
      const db = await getDB();
      const logs = await db.all(
        `SELECT id, userId, role, request, response, timestamp,
                prevHash, hash, flagged, flagReason
         FROM chat_logs
         ORDER BY id DESC
         LIMIT 200`
      );
      res.json({ logs });
    } catch (err) {
      console.error("Admin logs error", err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

export default router;
