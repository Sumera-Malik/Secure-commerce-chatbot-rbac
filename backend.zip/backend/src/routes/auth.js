// backend/src/routes/auth.js
import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import nodemailer from "nodemailer";
import { getDB } from "../config/db.js";
import { JWT_SECRET, EMAIL_USER, EMAIL_PASS } from "../config/env.js";
import { sanitizeBody } from "../middleware/sanitize.js";
import { revokeToken } from "../middleware/auth.js";
import {
  validateRegister,
  validateLogin,
  validateVerifyOtp
} from "../middleware/validation.js";

const router = express.Router();

// Nodemailer for OTP emails (if credentials configured)
const transporter =
  EMAIL_USER && EMAIL_PASS
    ? nodemailer.createTransport({
        service: "gmail",
        auth: { user: EMAIL_USER, pass: EMAIL_PASS }
      })
    : null;

// In-memory OTP store: email -> { code, expiresAt }
const otpStore = new Map();
const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes

function generateOtp() {
  const code = crypto.randomInt(0, 1_000_000).toString().padStart(6, "0");
  const expiresAt = Date.now() + OTP_TTL_MS;
  return { code, expiresAt };
}

async function sendOtp(email, code) {
  if (transporter) {
    try {
      await transporter.sendMail({
        from: EMAIL_USER,
        to: email,
        subject: "Your Secure Chatbot OTP",
        text: `Your one-time password is: ${code}. It is valid for 5 minutes.`
      });
      console.log(`OTP email sent to ${email}`);
    } catch (err) {
      console.error("Error sending OTP email", err);
      // Still log OTP to console in dev for testing
      console.log(`DEV OTP for ${email}: ${code}`);
    }
  } else {
    // Dev / fallback: log to console
    console.log(`DEV OTP for ${email}: ${code}`);
  }
}

// REGISTER
router.post("/register", validateRegister, sanitizeBody, async (req, res) => {
  const { name, email, password, role } = req.body || {};

  const normalizedEmail = String(email).toLowerCase().trim();

  // Enforce safe roles only (customer / agent) – no self-admin registration
  let safeRole = "customer";
  if (role === "agent") {
    safeRole = "agent";
  }

  try {
    const db = await getDB();
    const existing = await db.get(
      "SELECT id FROM users WHERE email = ?",
      normalizedEmail
    );
    if (existing) {
      return res.status(409).json({ message: "Email already registered." });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    await db.run(
      `INSERT INTO users (name, email, passwordHash, role, mfaEnabled)
       VALUES (?, ?, ?, ?, 1)`,
      [name.trim(), normalizedEmail, passwordHash, safeRole]
    );

    return res.status(201).json({
      message: "Registration successful. Please log in with your credentials."
    });
  } catch (err) {
    console.error("Register error", err);
    return res.status(500).json({ message: "Server error." });
  }
});

// LOGIN (phase 1 – password, then OTP)
router.post("/login", validateLogin, sanitizeBody, async (req, res) => {
  const { email, password } = req.body || {};

  const normalizedEmail = String(email).toLowerCase().trim();

  try {
    const db = await getDB();
    const user = await db.get(
      "SELECT id, name, email, passwordHash, role, mfaEnabled FROM users WHERE email = ?",
      normalizedEmail
    );

    if (!user) {
      return res.status(400).json({ message: "Invalid credentials." });
    }

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      return res.status(400).json({ message: "Invalid credentials." });
    }

    // If MFA disabled for any reason, issue token immediately
    if (!user.mfaEnabled) {
      const token = jwt.sign(
        {
          sub: user.id,
          role: user.role,
          name: user.name,
          email: user.email
        },
        JWT_SECRET,
        { expiresIn: "20m" }
      );
      return res.json({
        mfaRequired: false,
        accessToken: token
      });
    }

    // MFA enabled -> generate OTP and store in memory
    const { code, expiresAt } = generateOtp();
    otpStore.set(user.email, { code, expiresAt });

    await sendOtp(user.email, code);

    return res.json({
      mfaRequired: true,
      message:
        "Password accepted. An OTP has been sent to your email (or logged to console in dev)."
    });
  } catch (err) {
    console.error("Login error", err);
    return res.status(500).json({ message: "Server error." });
  }
});

// VERIFY OTP (phase 2)
router.post("/verify-otp", validateVerifyOtp, sanitizeBody, async (req, res) => {
  const { email, otp } = req.body || {};

  const normalizedEmail = String(email).toLowerCase().trim();

  try {
    const entry = otpStore.get(normalizedEmail);
    if (!entry) {
      return res.status(400).json({ message: "Invalid or expired OTP." });
    }

    const now = Date.now();
    if (now > entry.expiresAt || entry.code !== String(otp).trim()) {
      otpStore.delete(normalizedEmail);
      return res.status(400).json({ message: "Invalid or expired OTP." });
    }

    // OTP is valid – remove from store
    otpStore.delete(normalizedEmail);

    const db = await getDB();
    const user = await db.get(
      "SELECT id, name, email, role FROM users WHERE email = ?",
      normalizedEmail
    );
    if (!user) {
      return res
        .status(400)
        .json({ message: "User not found for provided email." });
    }

    const token = jwt.sign(
      {
        sub: user.id,
        role: user.role,
        name: user.name,
        email: user.email
      },
      JWT_SECRET,
      { expiresIn: "20m" }
    );

    return res.json({
      mfaRequired: false,
      accessToken: token
    });
  } catch (err) {
    console.error("MFA verify error", err);
    return res.status(500).json({ message: "Server error." });
  }
});

// LOGOUT – simple token revocation
router.post("/logout", (req, res) => {
  const header = req.headers.authorization;
  if (header && header.startsWith("Bearer ")) {
    const token = header.split(" ")[1];
    revokeToken(token);
  }
  return res.status(200).json({ message: "Logged out." });
});

export default router;
