// backend/server.js
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { PORT, CORS_ORIGIN } from "./src/config/env.js";
import { getDB } from "./src/config/db.js";
import authRoutes from "./src/routes/auth.js";
import chatRoutes from "./src/routes/chat.js";
import adminRoutes from "./src/routes/admin.js";

const app = express();

// Enforce HTTPS in production
app.use((req, res, next) => {
  const proto =
    req.headers["x-forwarded-proto"] || (req.secure ? "https" : "http");
  if (process.env.NODE_ENV === "production" && proto !== "https") {
    return res.redirect("https://" + req.headers.host + req.url);
  }
  next();
});

app.use(express.json());
app.use(
  cors({
    origin: CORS_ORIGIN,
    credentials: true
  })
);
app.use(helmet());

// Rate limiter for chat endpoint (NFR9)
const chatLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    message: "Too many chat requests, please slow down."
  }
});

// Health/status endpoint
app.get("/", (_req, res) => {
  res.json({ status: "Secure E-commerce Chatbot API running" });
});

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/chat", chatLimiter, chatRoutes);
app.use("/api/admin", adminRoutes);

// Initialize DB and start server
getDB()
  .then(() => console.log("SQLite DB ready"))
  .catch((err) => console.error("DB init error", err));

app.listen(PORT, () => {
  console.log(`Backend running at http://localhost:${PORT}`);
});
